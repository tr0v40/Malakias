
function load(){

}

function Down() {
	window.scroll({top:4500, behavior: 'smooth'})
}

if (window.location.search == '?contato' || window.location.search == '?login') {Down();
}

